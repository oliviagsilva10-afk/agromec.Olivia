import unittest

def custo_total(horas, itens):
    return horas * 85 + sum(qtd * valor for qtd, valor in itens)

def precisa_preventiva(atual, ultima):
    return atual - ultima >= 250

class TestRegras(unittest.TestCase):
    def test_custo(self):
        self.assertEqual(custo_total(5, [(1, 68.90), (1, 54.50)]), 548.40)

    def test_preventiva(self):
        self.assertFalse(precisa_preventiva(1549, 1300))
        self.assertTrue(precisa_preventiva(1550, 1300))

if __name__ == "__main__":
    unittest.main()
