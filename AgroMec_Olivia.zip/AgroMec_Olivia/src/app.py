from flask import Flask, render_template, request, redirect, session, flash, jsonify
import sqlite3, os
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = "agromec-chave"
DB = os.path.join(os.path.dirname(__file__), "agromec.db")

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys = ON")
    return c

def init():
    c = db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS usuarios(id INTEGER PRIMARY KEY, nome TEXT, login TEXT UNIQUE, senha TEXT);
    CREATE TABLE IF NOT EXISTS maquinas(id INTEGER PRIMARY KEY, patrimonio TEXT UNIQUE, tipo TEXT, modelo TEXT,
      ano INTEGER, horimetro REAL, ultima_preventiva REAL, status TEXT);
    CREATE TABLE IF NOT EXISTS mecanicos(id INTEGER PRIMARY KEY, nome TEXT, especialidade TEXT, ativo INTEGER);
    CREATE TABLE IF NOT EXISTS pecas(id INTEGER PRIMARY KEY, codigo TEXT UNIQUE, nome TEXT, valor REAL, estoque INTEGER, minimo INTEGER);
    CREATE TABLE IF NOT EXISTS os(id INTEGER PRIMARY KEY, maquina_id INTEGER, mecanico_id INTEGER, tipo TEXT,
      descricao TEXT, abertura TEXT, conclusao TEXT, horas REAL, status TEXT,
      FOREIGN KEY(maquina_id) REFERENCES maquinas(id), FOREIGN KEY(mecanico_id) REFERENCES mecanicos(id));
    CREATE TABLE IF NOT EXISTS itens_os(id INTEGER PRIMARY KEY, os_id INTEGER, peca_id INTEGER,
      quantidade INTEGER, valor_unitario REAL,
      FOREIGN KEY(os_id) REFERENCES os(id), FOREIGN KEY(peca_id) REFERENCES pecas(id));
    """)
    if c.execute("SELECT COUNT(*) FROM usuarios").fetchone()[0] == 0:
        c.execute("INSERT INTO usuarios VALUES(1,'Osvaldo Ribeiro','gerente',?)",
                  (generate_password_hash("Saep@2026"),))
        maquinas = [
            ("PAT-001","Trator","John Deere 6110J",2019,1480,1300,"Ativa"),
            ("PAT-002","Colheitadeira","Case IH 7150",2020,2240,1980,"Em manutenção"),
            ("PAT-003","Pulverizador","Jacto Uniport 3030",2021,1120,900,"Ativa"),
            ("PAT-004","Trator","Massey Ferguson 4707",2018,3350,3100,"Ativa"),
            ("PAT-005","Plantadeira","Tatu Marchesan PST",2022,640,500,"Em manutenção"),
            ("PAT-006","Trator","New Holland T7.245",2017,4119,3870,"Ativa")]
        c.executemany("INSERT INTO maquinas(patrimonio,tipo,modelo,ano,horimetro,ultima_preventiva,status) VALUES(?,?,?,?,?,?,?)", maquinas)
        mecanicos=[("Anderson Teixeira","Motores diesel",1),("Bruna Rezende","Hidráulica",1),
        ("Carlos Eduardo Lima","Elétrica",1),("Daniela Sousa","Transmissão",1),("Elias Moraes","Motores diesel",0)]
        c.executemany("INSERT INTO mecanicos(nome,especialidade,ativo) VALUES(?,?,?)", mecanicos)
        pecas=[("P001","Filtro de óleo do motor",68.90,25,10),("P002","Filtro de combustível",54.50,18,8),
        ("P003","Filtro de ar primário",132,6,8),("P004","Óleo 15W40 (balde 20 L)",489.90,9,4),
        ("P005","Correia do alternador",76.30,4,5),("P006",'Mangueira hidráulica 3/4"',214,7,3),
        ("P007","Bico de pulverização (un.)",38.70,40,20),("P008","Bateria 12V 150Ah",899,2,2)]
        c.executemany("INSERT INTO pecas(codigo,nome,valor,estoque,minimo) VALUES(?,?,?,?,?)", pecas)
        c.commit()
    c.close()

def custo(osid):
    c=db()
    row=c.execute("""SELECT COALESCE(horas,0) horas,
        (SELECT COALESCE(SUM(quantidade*valor_unitario),0) FROM itens_os WHERE os_id=?) pecas
        FROM os WHERE id=?""",(osid,osid)).fetchone()
    c.close()
    return (row["horas"] or 0)*85 + (row["pecas"] or 0)

def login_ok():
    return "user" in session

@app.route("/", methods=["GET","POST"])
def login():
    if request.method=="POST":
        c=db(); u=c.execute("SELECT * FROM usuarios WHERE login=?",(request.form["login"],)).fetchone(); c.close()
        if u and check_password_hash(u["senha"],request.form["senha"]):
            session["user"]=u["nome"]; return redirect("/home")
        flash("Login ou senha incorretos.")
    return render_template("login.html")

@app.route("/home")
def home():
    if not login_ok(): return redirect("/")
    c=db(); maquinas=c.execute("SELECT * FROM maquinas").fetchall()
    alertas=[m for m in maquinas if m["horimetro"]-m["ultima_preventiva"]>=250]
    c.close()
    return render_template("home.html", maquinas=maquinas, alertas=alertas)

@app.route("/logout")
def logout():
    session.clear(); return redirect("/")

@app.route("/maquinas", methods=["GET","POST"])
def maquinas():
    if not login_ok(): return redirect("/")
    c=db()
    if request.method=="POST":
        try:
            c.execute("""INSERT INTO maquinas(patrimonio,tipo,modelo,ano,horimetro,ultima_preventiva,status)
            VALUES(?,?,?,?,?,?,?)""",(request.form["patrimonio"],request.form["tipo"],request.form["modelo"],
            request.form["ano"],request.form["horimetro"],request.form["ultima_preventiva"],"Ativa"))
            c.commit(); flash("Máquina cadastrada.")
        except sqlite3.IntegrityError: flash("Patrimônio já cadastrado.")
    dados=c.execute("SELECT * FROM maquinas").fetchall(); c.close()
    return render_template("maquinas.html", maquinas=dados)

@app.route("/maquinas/excluir/<int:id>")
def excluir_maquina(id):
    if not login_ok(): return redirect("/")
    c=db()
    if c.execute("SELECT COUNT(*) FROM os WHERE maquina_id=?",(id,)).fetchone()[0]:
        flash("Não é possível excluir uma máquina com OS vinculada.")
    else:
        c.execute("DELETE FROM maquinas WHERE id=?",(id,)); c.commit(); flash("Máquina excluída.")
    c.close(); return redirect("/maquinas")

@app.route("/mecanicos", methods=["GET","POST"])
def mecanicos():
    if not login_ok(): return redirect("/")
    c=db()
    if request.method=="POST":
        c.execute("INSERT INTO mecanicos(nome,especialidade,ativo) VALUES(?,?,1)",
                  (request.form["nome"],request.form["especialidade"])); c.commit()
        flash("Mecânico cadastrado.")
    dados=c.execute("SELECT * FROM mecanicos").fetchall(); c.close()
    return render_template("mecanicos.html", mecanicos=dados)

@app.route("/mecanicos/status/<int:id>")
def mecanico_status(id):
    if not login_ok(): return redirect("/")
    c=db(); c.execute("UPDATE mecanicos SET ativo=CASE ativo WHEN 1 THEN 0 ELSE 1 END WHERE id=?",(id,)); c.commit(); c.close()
    return redirect("/mecanicos")

@app.route("/pecas", methods=["GET","POST"])
def pecas():
    if not login_ok(): return redirect("/")
    c=db()
    if request.method=="POST":
        try:
            c.execute("INSERT INTO pecas(codigo,nome,valor,estoque,minimo) VALUES(?,?,?,?,?)",
            (request.form["codigo"],request.form["nome"],request.form["valor"],request.form["estoque"],request.form["minimo"]))
            c.commit(); flash("Peça cadastrada.")
        except sqlite3.IntegrityError: flash("Código já cadastrado.")
    dados=c.execute("SELECT * FROM pecas").fetchall(); c.close()
    return render_template("pecas.html", pecas=dados)

@app.route("/os", methods=["GET","POST"])
def ordens():
    if not login_ok(): return redirect("/")
    c=db()
    if request.method=="POST":
        m=c.execute("SELECT * FROM maquinas WHERE id=?",(request.form["maquina"],)).fetchone()
        me=c.execute("SELECT * FROM mecanicos WHERE id=?",(request.form["mecanico"],)).fetchone()
        if m["status"]=="Em manutenção": flash("Essa máquina já está em manutenção.")
        elif not me["ativo"]: flash("Mecânico inativo não pode ser usado.")
        else:
            c.execute("""INSERT INTO os(maquina_id,mecanico_id,tipo,descricao,abertura,status)
            VALUES(?,?,?,?,date('now'),'Aberta')""",(m["id"],me["id"],request.form["tipo"],request.form["descricao"]))
            c.execute("UPDATE maquinas SET status='Em manutenção' WHERE id=?",(m["id"],)); c.commit(); flash("OS aberta.")
    dados=c.execute("""SELECT o.*,m.patrimonio,me.nome mecanico FROM os o
        JOIN maquinas m ON m.id=o.maquina_id JOIN mecanicos me ON me.id=o.mecanico_id
        ORDER BY o.id DESC""").fetchall()
    maquinas=c.execute("SELECT * FROM maquinas").fetchall()
    mecanicos=c.execute("SELECT * FROM mecanicos WHERE ativo=1").fetchall(); c.close()
    return render_template("os.html", os=dados, maquinas=maquinas, mecanicos=mecanicos, custo=custo)

@app.route("/os/<int:id>/item", methods=["POST"])
def item_os(id):
    if not login_ok(): return redirect("/os")
    c=db(); p=c.execute("SELECT * FROM pecas WHERE id=?",(request.form["peca"],)).fetchone()
    q=int(request.form["quantidade"])
    if q<=0 or q>p["estoque"]: flash("Quantidade maior que o estoque.")
    else:
        c.execute("INSERT INTO itens_os(os_id,peca_id,quantidade,valor_unitario) VALUES(?,?,?,?)",(id,p["id"],q,p["valor"]))
        c.execute("UPDATE pecas SET estoque=estoque-? WHERE id=?",(q,p["id"])); c.commit(); flash("Peça adicionada.")
    c.close(); return redirect("/os")

@app.route("/os/<int:id>/status/<status>", methods=["POST"])
def status_os(id,status):
    if not login_ok(): return redirect("/os")
    c=db(); o=c.execute("SELECT * FROM os WHERE id=?",(id,)).fetchone()
    if status=="Em andamento":
        c.execute("UPDATE os SET status='Em andamento' WHERE id=? AND status='Aberta'",(id,))
    elif status=="Cancelada":
        itens=c.execute("SELECT peca_id,quantidade FROM itens_os WHERE os_id=?",(id,)).fetchall()
        for i in itens: c.execute("UPDATE pecas SET estoque=estoque+? WHERE id=?",(i["quantidade"],i["peca_id"]))
        c.execute("UPDATE os SET status='Cancelada' WHERE id=?",(id,))
        c.execute("UPDATE maquinas SET status='Ativa' WHERE id=?",(o["maquina_id"],))
    elif status=="Concluída":
        horas=float(request.form.get("horas",0))
        data=request.form.get("conclusao")
        if horas<=0 or not data or data < o["abertura"]:
            flash("Informe horas maiores que zero e uma data válida.")
        else:
            c.execute("UPDATE os SET status='Concluída',horas=?,conclusao=? WHERE id=?",(horas,data,id))
            c.execute("UPDATE maquinas SET status='Ativa' WHERE id=?",(o["maquina_id"],))
            if o["tipo"]=="Preventiva":
                c.execute("UPDATE maquinas SET ultima_preventiva=horimetro WHERE id=?",(o["maquina_id"],))
            c.commit()
    c.commit(); c.close(); return redirect("/os")

@app.route("/relatorio")
def relatorio():
    if not login_ok(): return redirect("/")
    c=db(); dados=c.execute("SELECT o.*,m.patrimonio FROM os o JOIN maquinas m ON m.id=o.maquina_id WHERE o.status='Concluída'").fetchall()
    lista=[{"id":x["id"],"patrimonio":x["patrimonio"],"custo":custo(x["id"])} for x in dados]
    # Selection Sort feito no código
    for i in range(len(lista)):
        maior=i
        for j in range(i+1,len(lista)):
            if lista[j]["custo"]>lista[maior]["custo"]: maior=j
        lista[i],lista[maior]=lista[maior],lista[i]
    c.close(); return render_template("relatorio.html", dados=lista)

@app.route("/busca")
def busca():
    if not login_ok(): return redirect("/")
    termo=request.args.get("patrimonio","")
    c=db(); dados=c.execute("SELECT * FROM maquinas").fetchall(); c.close()
    # Busca sequencial
    achado=None
    for m in dados:
        if m["patrimonio"].lower()==termo.lower(): achado=m; break
    return render_template("busca.html", achado=achado, termo=termo)

@app.route("/api/horimetro", methods=["POST"])
def api_horimetro():
    data=request.get_json() or {}; c=db()
    m=c.execute("SELECT * FROM maquinas WHERE patrimonio=?",(data.get("patrimonio"),)).fetchone()
    if not m or float(data.get("horimetro",-1))<m["horimetro"]:
        c.close(); return jsonify({"erro":"Dados inválidos"}),400
    c.execute("UPDATE maquinas SET horimetro=? WHERE id=?",(data["horimetro"],m["id"])); c.commit(); c.close()
    return jsonify({"ok":True})

if __name__=="__main__":
    init()
    app.run(debug=False)
