# AgroMec

Sistema simples para controle de manutenção de máquinas agrícolas.

## Tecnologias
Python 3.11+, Flask, SQLite, HTML e CSS.

## Como executar
1. Abra o terminal na pasta `src`.
2. Instale as dependências:
   `pip install -r requirements.txt`
3. Execute:
   `python app.py`
4. Abra `http://127.0.0.1:5000`.

## Login
Usuário: `gerente`
Senha: `Saep@2026`

O banco SQLite é criado automaticamente na primeira execução.

## Requisitos
RF01 Login - Feito
RF02 Máquinas - Feito
RF03 Mecânicos - Feito
RF04 Peças - Feito
RF05 Abrir OS - Feito
RF06 Itens da OS - Feito
RF07 Andamento da OS - Feito
RF08 Consulta de OS - Feito
RF09 Alerta de preventiva - Feito
RF10 Relatório de custos - Feito
RF11 Busca por patrimônio - Feito

## Observação
A aplicação usa SQLite para facilitar a execução em outro computador.
