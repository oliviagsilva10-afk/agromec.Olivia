CREATE DATABASE IF NOT EXISTS agromec;
USE agromec;

CREATE TABLE usuarios (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(100) NOT NULL,
 login VARCHAR(50) NOT NULL UNIQUE,
 senha VARCHAR(255) NOT NULL
);

CREATE TABLE maquinas (
 id INT AUTO_INCREMENT PRIMARY KEY,
 patrimonio VARCHAR(20) NOT NULL UNIQUE,
 tipo VARCHAR(50) NOT NULL,
 modelo VARCHAR(100) NOT NULL,
 ano INT NOT NULL,
 horimetro DECIMAL(10,1) NOT NULL DEFAULT 0,
 ultima_preventiva DECIMAL(10,1) NOT NULL DEFAULT 0,
 status VARCHAR(30) NOT NULL DEFAULT 'Ativa'
);

CREATE TABLE mecanicos (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(100) NOT NULL,
 especialidade VARCHAR(100) NOT NULL,
 ativo BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE pecas (
 id INT AUTO_INCREMENT PRIMARY KEY,
 codigo VARCHAR(20) NOT NULL UNIQUE,
 nome VARCHAR(120) NOT NULL,
 valor DECIMAL(10,2) NOT NULL,
 estoque INT NOT NULL DEFAULT 0,
 minimo INT NOT NULL DEFAULT 0
);

CREATE TABLE ordens_servico (
 id INT AUTO_INCREMENT PRIMARY KEY,
 maquina_id INT NOT NULL,
 mecanico_id INT NOT NULL,
 tipo VARCHAR(20) NOT NULL,
 descricao VARCHAR(255) NOT NULL,
 abertura DATE NOT NULL,
 conclusao DATE NULL,
 horas DECIMAL(10,1) NULL,
 status VARCHAR(30) NOT NULL DEFAULT 'Aberta',
 FOREIGN KEY (maquina_id) REFERENCES maquinas(id),
 FOREIGN KEY (mecanico_id) REFERENCES mecanicos(id)
);

CREATE TABLE itens_os (
 id INT AUTO_INCREMENT PRIMARY KEY,
 os_id INT NOT NULL,
 peca_id INT NOT NULL,
 quantidade INT NOT NULL,
 valor_unitario DECIMAL(10,2) NOT NULL,
 FOREIGN KEY (os_id) REFERENCES ordens_servico(id),
 FOREIGN KEY (peca_id) REFERENCES pecas(id)
);

-- Usuário de aplicação no MySQL:
-- CREATE USER 'agromec_app'@'localhost' IDENTIFIED BY 'senha_app';
-- GRANT SELECT, INSERT, UPDATE, DELETE ON agromec.* TO 'agromec_app'@'localhost';
