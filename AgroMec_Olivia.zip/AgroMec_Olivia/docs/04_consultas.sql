-- Q1
SELECT m.patrimonio, me.nome AS mecanico
FROM maquinas m
JOIN ordens_servico o ON o.maquina_id=m.id
JOIN mecanicos me ON me.id=o.mecanico_id
WHERE o.status IN ('Aberta','Em andamento');

-- Q2
SELECT m.patrimonio,
       COALESCE(SUM(o.horas*85),0)+COALESCE(SUM(i.quantidade*i.valor_unitario),0) AS custo_total
FROM maquinas m
LEFT JOIN ordens_servico o ON o.maquina_id=m.id AND o.status='Concluída'
LEFT JOIN itens_os i ON i.os_id=o.id
GROUP BY m.id
ORDER BY custo_total DESC;

-- Q3
SELECT * FROM pecas WHERE estoque < minimo;

-- Q4
SELECT me.nome, COUNT(o.id) AS concluidas
FROM mecanicos me
LEFT JOIN ordens_servico o ON o.mecanico_id=me.id
AND o.status='Concluída'
AND o.conclusao BETWEEN '2026-08-01' AND '2026-08-31'
GROUP BY me.id;

-- Q5
SELECT * FROM ordens_servico
WHERE status NOT IN ('Concluída','Cancelada')
AND abertura < DATE('2026-09-29','-7 day');
