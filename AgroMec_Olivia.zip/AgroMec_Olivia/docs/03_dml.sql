INSERT INTO usuarios(nome,login,senha) VALUES
('Osvaldo Ribeiro','gerente','HASH_DA_SENHA');

INSERT INTO maquinas(patrimonio,tipo,modelo,ano,horimetro,ultima_preventiva,status) VALUES
('PAT-001','Trator','John Deere 6110J',2019,1480,1300,'Ativa'),
('PAT-002','Colheitadeira','Case IH 7150',2020,2240,1980,'Em manutenção'),
('PAT-003','Pulverizador','Jacto Uniport 3030',2021,1120,900,'Ativa'),
('PAT-004','Trator','Massey Ferguson 4707',2018,3350,3100,'Ativa'),
('PAT-005','Plantadeira','Tatu Marchesan PST',2022,640,500,'Em manutenção'),
('PAT-006','Trator','New Holland T7.245',2017,4119,3870,'Ativa');

INSERT INTO mecanicos(nome,especialidade,ativo) VALUES
('Anderson Teixeira','Motores diesel',1),
('Bruna Rezende','Hidráulica',1),
('Carlos Eduardo Lima','Elétrica',1),
('Daniela Sousa','Transmissão',1),
('Elias Moraes','Motores diesel',0);

INSERT INTO pecas(codigo,nome,valor,estoque,minimo) VALUES
('P001','Filtro de óleo do motor',68.90,25,10),
('P002','Filtro de combustível',54.50,18,8),
('P003','Filtro de ar primário',132.00,6,8),
('P004','Óleo 15W40 (balde 20 L)',489.90,9,4),
('P005','Correia do alternador',76.30,4,5),
('P006','Mangueira hidráulica 3/4"',214.00,7,3),
('P007','Bico de pulverização (un.)',38.70,40,20),
('P008','Bateria 12V 150Ah',899.00,2,2);
